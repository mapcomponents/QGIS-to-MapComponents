# MapComponents + vite + react + typescript

This template is based on the vite ts-react template, and adds all 
required basic components for a MapComponents application.

## Start the development server

```bash
yarn dev
```

## Build for production

```bash
yarn build
```
