<img src="cover.webp" alt="QGIS-MapComponentizer" width="300"/>

1. `mkdir tmp`
2. `npm i -g geostyler-cli`