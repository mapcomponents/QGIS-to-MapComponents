#!/bin/bash
yarn
yarn dev