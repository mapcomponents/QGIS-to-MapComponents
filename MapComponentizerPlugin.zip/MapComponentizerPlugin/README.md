<img src="cover.webp" alt="QGIS-MapComponentizer" width="300"/>

